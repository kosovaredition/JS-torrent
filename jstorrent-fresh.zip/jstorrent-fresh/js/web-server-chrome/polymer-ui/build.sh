vulcanize --inline-scripts --inline-css --strip-comments elements/elements.html | crisper --html build.html --js build.js
