var MAINWIN = 'mainWindow2'
var DEVMODE = false;
